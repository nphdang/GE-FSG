﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    class Edge
    {
        public int ix { get; set; } // node x
        public int iy { get; set; } // node y
        public int x { get; set; } // label(x)
        public int a { get; set; } // label(edge x-y)
        public int y { get; set; } // label(y)  

        public Edge()
        {
            this.ix = 0;
            this.iy = 0;
            this.x = 0;
            this.y = 0;
            this.a = 0;
        }

        public Edge(int ix, int iy, int x, int a, int y)
        {
            this.ix = ix;
            this.iy = iy;
            this.x = x;
            this.a = a;
            this.y = y;
        }

        public bool LessThan(Edge e)
        {
            if (this.ix > this.iy) // this is backward edge  
            {
                if (e.ix < e.iy) // e is forward edge 
                {
                    return true;
                }
                if (this.iy < e.iy || (this.iy == e.iy && this.a < e.a))
                {
                    return true;
                }
            }
            else if (e.ix < e.iy)
            {
                if (this.ix > e.ix)
                {
                    return true;
                }
                if (this.ix == e.ix)
                {
                    if (this.x < e.x)
                    {
                        return true;
                    }
                    if (this.x == e.x && (this.a < e.a || (this.a == e.a && this.y < e.y)))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
