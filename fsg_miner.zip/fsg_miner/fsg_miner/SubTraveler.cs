﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    /* traverse a subgraph and find its children in graph */
    class SubTraveler
    {
        public List<Edge> s { get; set; }
        public SubGraph g { get; set; }
        public List<Edge> c { get; set; }
        public int next { get; set; }
        public List<int> rm { get; set; } // rightmost path
        public List<int> s2g { get; set; }
        public List<int> g2s { get; set; }
        public List<List<bool>> f { get; set; }

        public SubTraveler(List<Edge> s, SubGraph g, List<Edge> c)
        {
            this.s = s;
            this.g = g;
            this.c = c;
        }

        private void DFS(int p, EdgeFrequency EF, double minSup)
        {
            int x, y;

            if (p >= s.Count)
            {
                /* grow from rightmost path, pruning stage (3) */
                int at = 0;
                while (at >= 0)
                {
                    x = s2g[at];
                    for (int i = 0; i < g.edge_label[x].Count; i++)
                    {
                        y = g.edge_next[x][i];
                        if (f[x][y])
                        {
                            continue;
                        }
                        int ix = g2s[x], iy = g2s[y];
                        Edge ne = new Edge(0, 1, g.node_label[x], g.edge_label[x][i], g.node_label[y]);
                        /* pruning */
                        if (EF.get(ne.x, ne.a, ne.y) < minSup)
                        {
                            continue;
                        }
                        /* pruning stage (1) */
                        if (ne.LessThan(s[0]))
                        {
                            continue;
                        }
                        /* pruning stage (2) */
                        if (iy >= 0)
                        {
                            if (ix <= iy)
                            {
                                continue;
                            }
                            bool flag = false;
                            for (int j = 0; j < g.edge_label[y].Count; j++)
                            {
                                int z = g.edge_next[y][j], w = g.edge_label[y][j];
                                if (!f[y][z])
                                {
                                    continue;
                                }
                                if (w > ne.a || (w == ne.a && g.node_label[z] > ne.x))
                                {
                                    flag = true;
                                    break;
                                }
                            }
                            if (flag)
                            {
                                continue;
                            }
                        }
                        else
                        {
                            iy = next;
                        }
                        ne.ix = ix;
                        ne.iy = iy;
                        if (!c.Contains(ne, new EdgeComparer()))
                        {
                            c.Insert(0, ne); // insert ne at the beginning of list
                        }
                    }
                    at = rm[at];
                }
                return;
            }

            Edge e = s[p];
            x = s2g[e.ix];

            for (int i = 0; i < g.edge_label[x].Count; i++)
            {
                if (g.edge_label[x][i] != e.a)
                {
                    continue;
                }
                y = g.edge_next[x][i];
                if (f[x][y])
                {
                    continue;
                }
                if (g.node_label[y] != e.y)
                {
                    continue;
                }
                if (s2g[e.iy] < 0 && g2s[y] < 0)
                {
                    s2g[e.iy] = y;
                    g2s[y] = e.iy;
                    f[x][y] = true;
                    f[y][x] = true;
                    DFS(p + 1, EF, minSup);
                    f[x][y] = false;
                    f[y][x] = false;
                    g2s[y] = -1;
                    s2g[e.iy] = -1;
                }
                else
                {
                    if (y != s2g[e.iy])
                    {
                        continue;
                    }
                    if (e.iy != g2s[y])
                    {
                        continue;
                    }
                    f[x][y] = true;
                    f[y][x] = true;
                    DFS(p + 1, EF, minSup);
                    f[x][y] = false;
                    f[y][x] = false;
                }
            }
        }

        public void travel(int _next, EdgeFrequency EF, double minSup)
        {
            next = _next;
            s2g = new List<int>();
            for (int a = 0; a < next; a++)
            {
                s2g.Add(-1);
            }
            g2s = new List<int>();
            for (int a = 0; a < g.node_label.Count; a++)
            {
                g2s.Add(-1);
            }
            f = new List<List<bool>>(g.node_label.Count);
            for (int a = 0; a < g.node_label.Count; a++)
            {
                bool[] b = new bool[g.node_label.Count];
                List<bool> sublist = new List<bool>(b);
                f.Add(sublist);
            }

            /* find rightmost path */
            rm = new List<int>();
            for (int a = 0; a < next; a++)
            {
                rm.Add(-1);
            }
            for (int i = 0; i < s.Count; i++)
            {
                if (s[i].iy > s[i].ix && s[i].iy > rm[s[i].ix])
                {
                    rm[s[i].ix] = s[i].iy;
                }
            }

            for (int i = 0; i < g.node_label.Count; i++)
            {
                if (g.node_label[i] != s[0].x)
                {
                    continue;
                }
                s2g[s[0].ix] = i;
                g2s[i] = s[0].ix;
                DFS(0, EF, minSup);
                g2s[i] = -1;
                s2g[s[0].ix] = -1;
            }
        }
    }
}
