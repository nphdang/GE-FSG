﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    class EdgeComparer : IEqualityComparer<Edge>
    {
        public bool Equals(Edge e1, Edge e2)
        {
            if (e1.ix == e2.ix && e1.iy == e2.iy && e1.x == e2.x && e1.a == e2.a && e1.y == e2.y)
            {
                return true;
            }

            return false;
        }

        public int GetHashCode(Edge e)
        {
            return e.ix ^ e.iy ^ e.x ^ e.a ^ e.y;
        }
    }
}
