﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    class SubGraph
    {
        public int id { get; set; } // subgraph id
        public List<int> node_label { get; set; }
        public List<List<int>> edge_next { get; set; }
        public List<List<int>> edge_label { get; set; }
        public List<int>[] gidset { get; set; } // list of graph ids that contain this subgraph

        public SubGraph(int n_label)
        {
            this.id = -1;
            this.node_label = new List<int>();
            this.edge_next = new List<List<int>>();
            this.edge_label = new List<List<int>>();
            this.gidset = new List<int>[n_label];
            for (int x = 0; x < n_label; x++)
            {
                this.gidset[x] = new List<int>();
            }
        }

        public void removeEdge(int x, int a, int y)
        {
            for (int i = 0; i < node_label.Count; i++)
            {
                int t;
                if (node_label[i] == x)
                {
                    t = y;
                }
                else if (node_label[i] == y)
                {
                    t = x;
                }
                else
                {
                    continue;
                }

                for (int j = 0; j < edge_next[i].Count; j++)
                {
                    if (edge_label[i][j] == a && node_label[edge_next[i][j]] == t)
                    {
                        /* remove edge */
                        edge_label[i][j] = edge_label[i].Last(); // get the last element  
                        edge_label[i].RemoveAt(edge_label[i].Count - 1); // remove the last element
                        edge_next[i][j] = edge_next[i].Last();
                        edge_next[i].RemoveAt(edge_next[i].Count - 1);
                        j--;
                    }
                }
            }
        }

        public bool hasEdge(int x, int a, int y)
        {
            for (int i = 0; i < node_label.Count; i++)
            {
                int t;
                if (node_label[i] == x)
                {
                    t = y;
                }
                else if (node_label[i] == y)
                {
                    t = x;
                }
                else
                {
                    continue;
                }

                for (int j = 0; j < edge_next[i].Count; j++) // set of edges connected to node i
                {
                    if (edge_label[i][j] == a && node_label[edge_next[i][j]] == t)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
