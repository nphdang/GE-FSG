﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    /* traverse a graph and find its minimal DFS code */
    class Traveler
    {
        public List<Edge> s { get; set; }
        public SubGraph g { get; set; }
        public bool is_min { get; set; }
        public List<int> g2s { get; set; }
        public List<List<bool>> f { get; set; }

        public Traveler(List<Edge> s, SubGraph g)
        {
            this.s = s;
            this.g = g;
            is_min = true;
        }

        private void DFS(List<int> v, int c, int next)
        {
            if (c >= this.s.Count)
            {
                return;
            }
            List<int> bak = new List<int>();
            while (v.Count != 0)
            {
                bool flag = false;
                int x = v.Last();
                for (int i = 0; i < g.edge_next[x].Count; i++)
                {
                    int y = g.edge_next[x][i];
                    if (f[x][y])
                    {
                        continue;
                    }
                    flag = true;
                    if (g2s[y] < 0)
                    {
                        Edge e = new Edge(g2s[x], next, g.node_label[x], g.edge_label[x][i], g.node_label[y]);
                        if (s[c].LessThan(e))
                        {
                            continue;
                        }
                        if (e.LessThan(s[c]))
                        {
                            is_min = false;
                            return;
                        }
                        g2s[y] = next;
                        v.Add(y);
                        f[x][y] = true;
                        f[y][x] = true;
                        DFS(v, c + 1, next + 1);
                        if (!is_min)
                        {
                            return;
                        }
                        f[x][y] = false;
                        f[y][x] = false;
                        v.RemoveAt(v.Count - 1);
                        g2s[y] = -1;
                    }
                    else
                    {
                        Edge e = new Edge(g2s[x], g2s[y], g.node_label[x], g.edge_label[x][i], g.node_label[y]);
                        if (s[c].LessThan(e))
                        {
                            continue;
                        }
                        if (e.LessThan(s[c]))
                        {
                            is_min = false;
                            return;
                        }
                        f[x][y] = true;
                        f[y][x] = true;
                        DFS(v, c + 1, next);
                        if (!is_min)
                        {
                            return;
                        }
                        f[x][y] = false;
                        f[y][x] = false;
                    }
                }
                if (flag)
                {
                    break;
                }
                bak.Add(v.Last());
                v.RemoveAt(v.Count - 1);
            }
            while (bak.Count() != 0)
            {
                v.Add(bak.Last());
                bak.RemoveAt(bak.Count - 1);
            }
        }

        public bool isMin()
        {
            return is_min;
        }

        public void travel()
        {
            g2s = new List<int>();
            for (int a = 0; a < g.node_label.Count; a++)
            {
                g2s.Add(-1);
            }
            f = new List<List<bool>>(g.node_label.Count);
            for (int a = 0; a < g.node_label.Count; a++)
            {
                bool[] b = new bool[g.node_label.Count];
                List<bool> sublist = new List<bool>(b);
                f.Add(sublist);
            }

            for (int i = 0; i < g.node_label.Count; i++)
            {
                int x = g.node_label[i];
                if (x > s[0].x)
                {
                    continue;
                }
                List<int> v = new List<int>(1);
                v.Add(i);
                g2s[i] = 0;
                DFS(v, 0, 1);
                g2s[i] = -1;
            }
        }
    }
}
