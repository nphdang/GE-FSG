﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;

namespace fsg_miner
{
    class Program
    {
        static int nSubGraph = 1; // keep track frequent subgraph id
        static int[] rank_to_node_label = null; // keep original node labels
        static int[] rank_to_edge_label = null; // keep original edge labels
        static List<SubGraph> SGs = new List<SubGraph>(); // list of frequent subgraphs

        #region parse parameters
        private static int ArgPos(string str, string[] args)
        {
            for (int a = 0; a < args.Length; a++)
            {
                if (str.Equals(args[a]))
                {
                    if (a == args.Length - 1)
                    {
                        throw new ArgumentException(string.Format("Argument missing for {0}", str));
                    }

                    return a;
                }
            }

            return -1;
        }
        #endregion

        #region gSpan function
        static void gSpan(GraphData dt_graph, double minSup)
        {
            // obtain graphs (deep copy)
            List<Graph> graphset = new List<Graph>();
            foreach (Graph gr in dt_graph.data)
            {
                Graph g = gr.DeepCopy();
                graphset.Add(g);
            }
            // obtain graph labels
            List<int> graph_labels = dt_graph.labels;
            // obtain other graph information
            int NODE_LABEL_MAX = dt_graph.n_node_label;
            int EDGE_LABEL_MAX = dt_graph.n_edge_label;
            int[] freq_node_label = dt_graph.freq_node_label;
            int[] freq_edge_label = dt_graph.freq_edge_label;
            int n_label = dt_graph.n_label;

            /* sort labels of nodes and edges in GS by their frequency */
            int[] rank_node_label = new int[NODE_LABEL_MAX + 1];
            int[] rank_edge_label = new int[EDGE_LABEL_MAX + 1];
            // initialize a rank for each node label and edge label
            for (int i = 0; i <= NODE_LABEL_MAX; i++)
            {
                rank_node_label[i] = i;
            }
            for (int i = 0; i <= EDGE_LABEL_MAX; i++)
            {
                rank_edge_label[i] = i;
            }
            // sort node labels by their frequency
            for (int i = NODE_LABEL_MAX; i > 0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    int tmp;
                    if (freq_node_label[rank_node_label[j]] < freq_node_label[rank_node_label[j + 1]])
                    {
                        tmp = rank_node_label[j];
                        rank_node_label[j] = rank_node_label[j + 1];
                        rank_node_label[j + 1] = tmp;
                    }
                }
            }
            // sort edge labels by their frequency
            for (int i = EDGE_LABEL_MAX; i > 0; i--)
            {
                for (int j = 0; j < i; j++)
                {
                    int tmp;
                    if (freq_edge_label[rank_edge_label[j]] < freq_edge_label[rank_edge_label[j + 1]])
                    {
                        tmp = rank_edge_label[j];
                        rank_edge_label[j] = rank_edge_label[j + 1];
                        rank_edge_label[j + 1] = tmp;
                    }
                }
            }

            // rank_node_label and rank_edge_label store node labels and edge labels sorted in descending frequency
            // e.g., rank_node_label = [2, 1, 0, 4, 0] meaning node label 2 has the highest support 
            // while node label 0 has the third highest support. we don't consider the last element 0

            int max_node_label = 0, max_edge_label = 0;
            // compute the maximum node label that is still frequent
            for (int i = 0; i <= NODE_LABEL_MAX; i++)
            {
                if (freq_node_label[rank_node_label[i]] >= minSup)
                {
                    max_node_label = i;
                }
            }
            // compute the maximum edge label that is still frequent
            for (int i = 0; i <= EDGE_LABEL_MAX; i++)
            {
                if (freq_edge_label[rank_edge_label[i]] >= minSup)
                {
                    max_edge_label = i;
                }
            }
            // keep original node labels
            Array.Copy(rank_node_label, rank_to_node_label, rank_to_node_label.Length);
            for (int i = 0; i <= NODE_LABEL_MAX; i++)
            {
                rank_node_label[rank_to_node_label[i]] = i;
            }
            // keep original edge labels
            Array.Copy(rank_edge_label, rank_to_edge_label, rank_to_edge_label.Length);
            for (int i = 0; i <= EDGE_LABEL_MAX; i++)
            {
                rank_edge_label[rank_to_edge_label[i]] = i;
            }

            /* remove infrequent nodes and edges */
            /* relabel the remaining nodes and edges in descending frequency */
            for (int i = 0; i < graphset.Count; i++)
            {
                Graph graph = graphset[i];
                // re-map node and edge labels
                for (int j = 0; j < graph.nodel.Count; j++)
                {
                    if (freq_node_label[graph.nodel[j]] < minSup)
                    {
                        graph.nodev[j] = false; // remove node
                    }
                    else
                    {
                        // relabel a node label in a graph
                        graph.nodel[j] = rank_node_label[graph.nodel[j]];
                    }
                }
                for (int j = 0; j < graph.edgel.Count; j++)
                {
                    // source node or target node is false (infrequent)
                    if (!graph.nodev[graph.edgex[j]] || !graph.nodev[graph.edgey[j]])
                    {
                        graph.edgev[j] = false; // remove edge  
                        continue;
                    }
                    if (freq_edge_label[graph.edgel[j]] < minSup)
                    {
                        graph.edgev[j] = false; // remove edge
                    }
                    else
                    {
                        // relabel an edge label in a graph
                        graph.edgel[j] = rank_edge_label[graph.edgel[j]];
                    }
                }

                /* re-map node index */
                Dictionary<int, int> m = new Dictionary<int, int>();
                int cur = 0;
                for (int j = 0; j < graph.nodel.Count; j++)
                {
                    if (!graph.nodev[j])
                    {
                        continue;
                    }
                    m[j] = cur++;
                }
                for (int j = 0; j < graph.edgel.Count; j++)
                {
                    if (!graph.edgev[j])
                    {
                        continue;
                    }
                    graph.edgex[j] = m[graph.edgex[j]];
                    graph.edgey[j] = m[graph.edgey[j]];
                }
            }

            /* build graph set */
            // convert dataset of graphs to datasets of subgraphs
            int n_graph = graphset.Count; // number of graphs
            SubGraph[] subgraphs = new SubGraph[n_graph];
            for (int i = 0; i < n_graph; i++)
            {
                SubGraph sg = new SubGraph(n_label);
                Graph graph = graphset[i];
                for (int j = 0; j < graph.nodel.Count; j++)
                {
                    if (graph.nodev[j])
                    {
                        sg.node_label.Add(graph.nodel[j]);
                    }
                }
                for (int a = 0; a < sg.node_label.Count; a++)
                {
                    sg.edge_next.Add(new List<int>());
                }
                for (int a = 0; a < sg.node_label.Count; a++)
                {
                    sg.edge_label.Add(new List<int>());
                }
                for (int j = 0; j < graph.edgel.Count; j++)
                {
                    if (!graph.edgev[j])
                    {
                        continue;
                    }
                    sg.edge_label[graph.edgex[j]].Add(graph.edgel[j]);
                    sg.edge_label[graph.edgey[j]].Add(graph.edgel[j]);
                    sg.edge_next[graph.edgex[j]].Add(graph.edgey[j]);
                    sg.edge_next[graph.edgey[j]].Add(graph.edgex[j]);
                }

                subgraphs[i] = sg;
            }

            /* find all subgraphs with only one node for reference */
            for (int i = 0; i <= max_node_label; i++)
            {
                SubGraph sg = new SubGraph(n_label);
                sg.node_label.Add(i);
                for (int j = 0; j < n_graph; j++)
                {
                    SubGraph gr = subgraphs[j]; // this one is a graph indeed
                                                // get graph label
                    int label = graph_labels[j];
                    // check whether a graph contains this subgraph
                    if (gr.node_label.Contains(i))
                    {
                        sg.gidset[label].Add(j);
                    }
                }
                // compute support of this subgraph
                int supp = 0;
                foreach (List<int> gids in sg.gidset)
                {
                    supp += gids.Count;
                }
                if (supp >= minSup)
                {
                    sg.id = nSubGraph;
                    nSubGraph++;
                    SGs.Add(sg); // this subgraph contains one node, no edges
                }
            }

            /* enumerate all frequent 1-edge graphs in GS */
            EdgeFrequency EF = new EdgeFrequency();
            EF.init(max_node_label, max_edge_label);

            for (int x = 0; x <= max_node_label; x++)
            {
                for (int a = 0; a <= max_edge_label; a++)
                {
                    for (int y = x; y <= max_node_label; y++)
                    {
                        int count = 0;
                        for (int i = 0; i < n_graph; i++)
                        {
                            if (subgraphs[i].hasEdge(x, a, y))
                            {
                                count++;
                            }
                        }

                        EF.set(x, a, y, count);
                        EF.set(y, a, x, count);
                    }
                }
            }

            List<GraphCode> Lr = new List<GraphCode>(); // root node of graph tree
            for (int x = 0; x <= max_node_label; x++)
            {
                for (int a = 0; a <= max_edge_label; a++)
                {
                    for (int y = x; y <= max_node_label; y++)
                    {
                        if (EF.get(x, a, y) < minSup) // check whether this subgraph (an edge) is frequent
                        {
                            continue;
                        }
                        GraphCode gc = new GraphCode(n_label);
                        for (int i = 0; i < n_graph; i++)
                        {
                            // get graph label
                            int label = graph_labels[i];
                            // check whether a graph contains this subgraph
                            if (subgraphs[i].hasEdge(x, a, y)) // this one is graph indeed
                            {
                                gc.gidset[label].Add(i);
                            }
                        }

                        Edge e = new Edge(0, 1, x, a, y);
                        gc.seq.Add(e);

                        // add the node to root node
                        Lr.Add(gc);
                    }
                }
            }

            // parallelize frequent subgraph mining
            List<Task<List<SubGraph>>> listTasks = new List<Task<List<SubGraph>>>();
            foreach (GraphCode gc in Lr)
            {
                List<SubGraph> LocalGraphs = new List<SubGraph>();
                Task<List<SubGraph>> tasks = new Task<List<SubGraph>>((stateObject) =>
                {
                    List<SubGraph> isolatedGraphs = (List<SubGraph>)stateObject;
                    subgraph_mining(subgraphs, gc, 2, EF, minSup, isolatedGraphs, n_label, graph_labels);
                    return isolatedGraphs;
                }, LocalGraphs);
                listTasks.Add(tasks);
                tasks.Start();
            }

            foreach (Task<List<SubGraph>> t in listTasks)
            {
                foreach (SubGraph sg in t.Result)
                {
                    sg.id = nSubGraph;
                    nSubGraph++;
                    SGs.Add(sg);
                }
            }
        }
        #endregion

        #region frequent subgraph mining
        static void subgraph_mining(SubGraph[] GS, GraphCode gc, int next, EdgeFrequency EF, double minSup, 
            List<SubGraph> S, int n_label, List<int> graph_labels)
        {
            /* construct graph from DFS code */
            SubGraph sg = new SubGraph(n_label);
            List<Edge> s = gc.seq;
            int[] nl = new int[next];
            sg.node_label = new List<int>(nl);
            for (int a = 0; a < next; a++)
            {
                sg.edge_label.Add(new List<int>());
            }
            for (int a = 0; a < next; a++)
            {
                sg.edge_next.Add(new List<int>());
            }
            for (int i = 0; i < s.Count; i++)
            {
                int ix = s[i].ix, iy = s[i].iy, a = s[i].a;
                sg.node_label[ix] = s[i].x;
                sg.node_label[iy] = s[i].y;
                sg.edge_label[ix].Add(a);
                sg.edge_label[iy].Add(a);
                sg.edge_next[ix].Add(iy);
                sg.edge_next[iy].Add(ix);
            }

            /* minimum DFS code pruning stage (4) */
            Traveler t = new Traveler(s, sg);
            t.travel();
            if (!t.isMin())
            {
                return;
            }

            S.Add(sg);

            /* enumerate potential children with 1-edge growth */
            EdgeComparer edgeComparer = new EdgeComparer();
            Dictionary<Edge, List<int>> m = new Dictionary<Edge, List<int>>(edgeComparer);
            // convert array of list to list
            List<int> gc_gidset = new List<int>();
            for (int x = 0; x < n_label; x++)
            {
                gc_gidset.AddRange(gc.gidset[x]);
            }
            for (int i = 0; i < gc_gidset.Count; i++)
            {
                List<Edge> c = new List<Edge>(); // c does not contain duplicate elements
                SubTraveler st = new SubTraveler(s, GS[gc_gidset[i]], c);
                st.travel(next, EF, minSup);
                // sort s in DFS lexicographic order
                for (int a = 0; a < c.Count - 1; a++)
                {
                    for (int b = a + 1; b < c.Count; b++)
                    {
                        if (c[b].LessThan(c[a]))
                        {
                            Edge tmp = c[a];
                            c[a] = c[b];
                            c[b] = tmp;
                        }
                    }
                }
                foreach (Edge j in c)
                {
                    if (m.Keys.Contains(j, edgeComparer))
                    {
                        m[j].Add(gc_gidset[i]);
                    }
                    else
                    {
                        m.Add(j, new List<int>() { gc_gidset[i] });
                    }
                }
            }

            /* mining subgraph children */
            foreach (var i in m)
            {
                Edge e = i.Key;
                List<int> spp = i.Value; // list of graph ids
                if (spp.Count < minSup)
                {
                    continue;
                }
                GraphCode child_gc = new GraphCode(n_label);
                foreach (int graph_id in spp)
                {
                    int label = graph_labels[graph_id];
                    child_gc.gidset[label].Add(graph_id);
                }
                child_gc.seq = new List<Edge>(s); // clone  
                child_gc.seq.Add(e);
                int next1 = next;
                if (e.iy == next)
                {
                    next1 += 1;
                }
                subgraph_mining(GS, child_gc, next1, EF, minSup, S, n_label, graph_labels);
            }
            sg.gidset = gc.gidset;
        }
        #endregion

        # region write frequent subgraphs to file
        static void writeFSG(string subgraph_file, List<SubGraph> SGs, int n_graph, int n_label)
        {
            using (StreamWriter sw = new StreamWriter(subgraph_file))
            {
                for (int i = 0; i < SGs.Count; ++i)
                {
                    SubGraph sg = SGs[i];
                    int size = sg.node_label.Count;
                    // obtain all graph ids containing this subgraph
                    List<int> gids = new List<int>();
                    for (int x = 0; x < n_label; x++)
                    {
                        gids.AddRange(sg.gidset[x]);
                    }
                    double supp = Math.Round((double)gids.Count / n_graph, 4);
                    sw.WriteLine("t # " + sg.id + " size " + size + " supp " + supp);
                    for (int j = 0; j < sg.node_label.Count; j++)
                    {
                        sw.WriteLine("v " + j + " " + rank_to_node_label[sg.node_label[j]]);
                    }
                    // this subgraph has a single node
                    if (sg.node_label.Count < 2)
                    {
                        // write list of graph ids that contain this subgraph
                        sw.WriteLine("gidset " + string.Join(" ", gids));
                        continue;
                    }
                    for (int j = 0; j < sg.node_label.Count; j++)
                    {
                        for (int k = 0; k < sg.edge_label[j].Count; k++)
                        {
                            // node 0 connects to node 1, just write the edge from node 0 to node 1
                            // don't write the edge from node 1 to node 0
                            if (j < sg.edge_next[j][k])
                            {
                                sw.WriteLine("e " + j + " " + sg.edge_next[j][k] + " " +
                                                rank_to_edge_label[sg.edge_label[j][k]]);
                            }
                        }
                    }
                    // write list of graph ids that contain this subgraph
                    sw.WriteLine("gidset " + string.Join(" ", gids));
                }
            }
        }
        #endregion

        #region write graphs represented by frequent subgraphs to file
        static void writeTransSGs(string trans_file, List<SubGraph> SGs, GraphData dt_data)
        {
            // map a trans to subgraphs
            using (StreamWriter sw = new StreamWriter(trans_file))
            {
                for (int i = 0; i < dt_data.n_row; i++)
                {
                    int label = dt_data.labels[i];
                    List<string> graphset = new List<string>();
                    foreach (SubGraph sg in SGs)
                    {
                        if (sg.gidset[label].Contains(i))
                        {
                            graphset.Add(sg.id.ToString());
                        }
                    }
                    sw.WriteLine(label + "\t" + string.Join(" ", graphset));
                }
            }
        }
        #endregion

        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("mining frequent subgraphs (FSGs)...");                
                Console.WriteLine("\t-graphset <file>");
                Console.WriteLine("\tuse graphs from <file> to mine FSGs");
                Console.WriteLine("\t-graphlabel <file>");
                Console.WriteLine("\tobtain graph labels from <file>");
                Console.WriteLine("\t-minsup <float>");
                Console.WriteLine("\tset minimum support threshold in [0,1]; default is 0.5");
                Console.WriteLine("\t-fsg <file>");
                Console.WriteLine("\tsave discovered FSGs to <file> (optional)");
                Console.WriteLine("\t-output <file>");
                Console.WriteLine("\tconvert each graph to a set of FSGs and save it to <file> (optional)");

                return;
            }
            int para_id = 0;
            string in_graph = "";
            string in_graph_label = "";
            double r_minSup = 0;
            string out_fsg = "";
            string out_graph_fsg = "";
            if ((para_id = ArgPos("-graphset", args)) > -1)
            {
                in_graph = args[para_id + 1];
            }
            if ((para_id = ArgPos("-graphlabel", args)) > -1)
            {
                in_graph_label = args[para_id + 1];
            }
            if ((para_id = ArgPos("-minsup", args)) > -1)
            {
                r_minSup = double.Parse(args[para_id + 1]);
            }
            if ((para_id = ArgPos("-fsg", args)) > -1)
            {
                out_fsg = args[para_id + 1];
            }
            if ((para_id = ArgPos("-output", args)) > -1)
            {
                out_graph_fsg = args[para_id + 1];
            }

            // load graph data
            GraphData dt_data = new GraphData();
            dt_data.loadGraphData(in_graph, in_graph_label);
            Stopwatch sw = Stopwatch.StartNew();
            // initialize values
            rank_to_node_label = new int[dt_data.n_node_label + 1];
            rank_to_edge_label = new int[dt_data.n_edge_label + 1];
            // set absolute minSup
            double m = r_minSup * dt_data.n_row;
            double minSup = (int)m;
            if (Math.Abs(minSup - m) >= 0.5)
            {
                minSup++;
            }
            if (minSup < 1)
            {
                minSup = 1;
            }
            // mine frequent subgraphs
            gSpan(dt_data, minSup);
            Console.WriteLine("minSup: " + r_minSup + ", FSGs: " + SGs.Count);
            // write frequent subgraphs to file
            if (out_fsg != "")
            {
                if (SGs.Count > 0)
                {
                    writeFSG(out_fsg, SGs, dt_data.n_row, dt_data.n_label);
                }
            }
            // write graphs represented by frequent subgraphs to file
            if (out_graph_fsg != "")
            {
                if (SGs.Count > 0)
                {
                    writeTransSGs(out_graph_fsg, SGs, dt_data);
                }
            }
            sw.Stop();
            long time = sw.ElapsedMilliseconds;
            Console.WriteLine("runtime: " + time / 1000.0 + " (s)");
        }
    }
}
