﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    class Graph
    {
        public int id { get; set; } // graph id
        public int label { get; set; } // graph label
        public List<int> nodel { get; set; } // list of node labels in the graph
        public List<bool> nodev { get; set; } // indicate whether a node is visible or not
        public List<int> edgex { get; set; } // list of first node ids to create edges
        public List<int> edgey { get; set; } // list of second node ids to create edges
        public List<int> edgel { get; set; } // list of edge labels in the graph
        public List<bool> edgev { get; set; } // indicate whether an edge is visible or not

        public Graph()
        {
            this.id = -1;
            this.label = -1;
            this.nodel = new List<int>();
            this.nodev = new List<bool>();
            this.edgex = new List<int>();
            this.edgey = new List<int>();
            this.edgel = new List<int>();
            this.edgev = new List<bool>();
        }

        public Graph DeepCopy()
        {
            Graph other = (Graph)this.MemberwiseClone();
            other.nodel = new List<int>(this.nodel);
            other.nodev = new List<bool>(this.nodev);
            other.edgex = new List<int>(this.edgex);
            other.edgey = new List<int>(this.edgey);
            other.edgel = new List<int>(this.edgel);
            other.edgev = new List<bool>(this.edgev);

            return other;
        }
    }
}
