﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    class EdgeFrequency
    {
        public int u { get; set; }
        public int v { get; set; }
        public int[] array { get; set; }


        public void init(int max_node_label, int max_edge_label)
        {
            this.u = max_node_label + 1;
            this.v = this.u * (max_edge_label + 1);
            this.array = new int[this.u * this.v];
        }

        public void set(int x, int a, int y, int value)
        {
            this.array[x * v + a * u + y] = value;
        }

        public int get(int x, int a, int y)
        {
            return this.array[x * v + a * u + y];
        }
    }
}
