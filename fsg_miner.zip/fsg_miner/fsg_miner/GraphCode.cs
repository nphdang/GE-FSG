﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fsg_miner
{
    // DFS code of a subgraph is a sequence of extended edge tuples listed in the DFS edge order 
    class GraphCode
    {
        public List<Edge> seq { get; set; }
        public List<int>[] gidset { get; set; } // list of graph ids that contain this subgraph

        public GraphCode(int n_label)
        {
            this.seq = new List<Edge>();
            this.gidset = new List<int>[n_label];
            for (int x = 0; x < n_label; x++)
            {
                this.gidset[x] = new List<int>();
            }
        }
    }
}
