﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fsg_miner
{
    class GraphData
    {
        public int n_row { get; set; }
        public int n_label { get; set; }
        public int n_node_label { get; set; }
        public int n_edge_label { get; set; }
        public Dictionary<int, int> rows_labels { get; set; } // {<label id>: # of transactions containing label id}
        public List<Graph> data { get; set; }
        public List<int> labels { get; set; } // store label id of each graph
        public int[] freq_node_label { get; set; } // keep track support of node labels
        public int[] freq_edge_label { get; set; } // keep track support of edge labels

        public GraphData()
        {
            this.n_row = 0;
            this.n_label = 0;
            this.n_node_label = 1; // default # of node labels is 1 and that node label is "0"
            this.n_edge_label = 1; // default # of edge labels is 1 and that edge label is "0"
            this.rows_labels = new Dictionary<int, int>();
            this.data = new List<Graph>();
            this.labels = new List<int>();
            this.freq_node_label = new int[this.n_node_label + 1];
            this.freq_edge_label = new int[this.n_edge_label + 1];
        }

        public void loadGraphData(string graph_file, string label_file)
        {
            this.n_node_label = 1000; // initialize a max number for # of node labels
            this.n_edge_label = 20; // initialize a max number for # of edge labels
            List<int> node_labels = new List<int>(); // store label of each node
            string line = "";
            // read graph label
            using (StreamReader sr = File.OpenText(label_file))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    line = line.Trim();
                    string[] content = line.Split('\t');
                    if (content.Count() > 1)
                    {
                        this.labels.Add(int.Parse(content[0]));
                    }
                }
            }
            // read graph data
            using (StreamReader sr = File.OpenText(graph_file))
            {
                // keep track support of node labels and edge labels
                this.freq_node_label = new int[this.n_node_label + 1];
                this.freq_edge_label = new int[this.n_edge_label + 1];
                // keep track occurrence of node labels and edge labels
                bool[] occ_node_label = new bool[this.n_node_label + 1];
                bool[] occ_edge_label = new bool[this.n_edge_label + 1];
                Graph graph = null;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.Contains("t")) // graph
                    {
                        // existing graph
                        if (graph != null)
                        {
                            this.data.Add(graph);
                            // compute frequency of a single node
                            for (int i = 0; i <= this.n_node_label; i++)
                            {
                                if (occ_node_label[i]) // this node label appears in a graph
                                {
                                    freq_node_label[i]++; // increase its support
                                }
                            }
                            // compute frequency of a single edge
                            for (int i = 0; i <= this.n_edge_label; i++)
                            {
                                if (occ_edge_label[i]) // this edge label appears in a graph
                                {
                                    freq_edge_label[i]++; // increase its support
                                }
                            }
                        }
                        // new graph
                        graph = new Graph();
                        graph.id = int.Parse(line.Split()[2]); // graph id
                        graph.label = this.labels[graph.id]; // graph label
                        // reset values
                        occ_node_label = new bool[this.n_node_label + 1];
                        occ_edge_label = new bool[this.n_edge_label + 1];
                    }
                    else if (line.Contains("v")) // node
                    {
                        int id = int.Parse(line.Split()[1]); // node id
                        int label = int.Parse(line.Split()[2]); // node label
                        node_labels.Add(label);
                        graph.nodel.Add(label);
                        graph.nodev.Add(true);
                        occ_node_label[label] = true;
                    }
                    else if (line.Contains("e")) // edge
                    {
                        int x = int.Parse(line.Split()[1]); // first node id to create an edge
                        int y = int.Parse(line.Split()[2]); // second node id to create an edge
                        int label = int.Parse(line.Split()[3]); // edge label
                        graph.edgex.Add(x);
                        graph.edgey.Add(y);
                        graph.edgel.Add(label);
                        graph.edgev.Add(true);
                        occ_edge_label[label] = true;
                    }
                }

                // end of file
                if (graph != null)
                {
                    this.data.Add(graph);
                    // compute frequency of a single node
                    for (int i = 0; i <= this.n_node_label; i++)
                    {
                        if (occ_node_label[i])
                        {
                            freq_node_label[i]++;
                        }
                    }
                    // compute frequency of a single edge
                    for (int i = 0; i <= this.n_edge_label; i++)
                    {
                        if (occ_edge_label[i])
                        {
                            freq_edge_label[i]++;
                        }
                    }
                }
            }
            // compute other information of graph data
            this.n_row = this.labels.Count;
            List<int> distinct_labels = this.labels.Distinct().ToList();
            this.n_label = distinct_labels.Count;
            this.n_node_label = node_labels.Distinct().ToList().Count; // compute real number of node labels
            this.rows_labels = this.labels.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        }
    }
}
